from setuptools import setup, find_packages

setup(
    name='ogs-account-generator',
    version='1.0.2',
    author='changcheng967',
    author_email='changcheng6541@gmail.com',
    description='Automated account generator for Online-Go.com',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    url='https://github.com/changcheng967/ogs-account-generator',
    packages=find_packages(),
    install_requires=[
        'selenium',
        # Add any other dependencies here
    ],
    entry_points={
        'console_scripts': [
            'ogs-account-generator=ogs_account_generator.main:main',
        ],
    },
)
